﻿namespace BackgroundJobCodingChallenge
{
	public static class Program
	{
		public static void Main(string[] args)
		{
			// No need to write code here!
		}
	}
}
